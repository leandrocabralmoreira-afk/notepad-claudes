// Scintilla source code edit control
/** @file Position.h
 ** Defines global type name Position in the Sci internal namespace.
 **/
// Copyright 2015 by Neil Hodgson <neilh@scintilla.org>
// The License.txt file describes the conditions under which this software may be distributed.
#pragma once

/**
 * A Position is a position within a document between two characters or at the beginning or end.
 * Sometimes used as a character index where it identifies the character after the position.
 * A Line is a document or screen line.
 */

namespace Sci {

using Position = ptrdiff_t;
using Line = ptrdiff_t;

constexpr Position invalidPosition = -1;

}

namespace Scintilla::Internal {

// Bit set of marker numbers.
using MarkerMask = unsigned int;

}
